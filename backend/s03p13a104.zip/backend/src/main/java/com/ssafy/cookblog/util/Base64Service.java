package com.ssafy.cookblog.util;

public interface Base64Service {
	public String encode(String input);
	public String decode(String input);
}
