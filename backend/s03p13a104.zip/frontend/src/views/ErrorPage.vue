<template>
  <div class="wrapper">
    <div class="page-header page-header-mini">
      <parallax
        class="page-header-image"
        style="background-image: url('https://livwanillustration.com/portfolio/recipe-illustrations/french-food-illustrations.jpg') ;"
      ></parallax>

      <div class="container">
        <h1 class="title">페이지를 찾을 수 없습니다</h1>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ErrorPage'
}
</script>
