<template>
  <div class="wrapper landing-page">
    
    <div class="page-header">
      <parallax
        class="page-header-image" style="background-size:80%"
        :style="{ backgroundImage: 'url(http://i3a104.p.ssafy.io/header/home.gif)' }"
      ></parallax>
      <div class="content-center">
        <h1 class="title">코~옥이 뭔가요?</h1>
        <h2>코옥 탐방하기</h2>
      </div>
    </div>
    
    <div class="section">
      <div class="about-description text-center">
        <div class="features-3 pt-0">
          <div class="container">
            <div class="row">
              <div class="col-md-8 mr-auto ml-auto">
                <h2 class="title">코×옥이란?</h2>
                <h4 class="description">
                  요리가 쉬워질 수 있게
                  <br />요리를 따라할 수 있게
                  <br />혼자서 힘들다면 다른 사람과 함께
                  <br />만든 음식을 다른 사람과 함께
                </h4>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="info info-hover">
                  <div class="icon icon-success icon-circle">
                    <i class="now-ui-icons education_paper"></i>
                  </div>
                  <h4 class="info-title">똑똑하고 쉬운 레시피</h4>
                  <p class="description">다양한 레시피를 난이도부터 영양소까지</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info info-hover">
                  <div class="icon icon-info icon-circle">
                    <i class="now-ui-icons education_atom"></i>
                  </div>
                  <h4 class="info-title">다른 사람과 함께</h4>
                  <p class="description">다른 사람과 함께 해서 요리를 쉽고 즐겁게</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="separator-line separator-primary"></div>
      <div class="about-team team-4">
        <div class="container">
          <div class="row">
            <div class="col-xl-6 col-lg-7 ml-auto mr-auto">
              <card type="profile" plain>
                <div slot="raw-content" class="row">
                  <div class="col-md-5">
                    <div class="card-image">
                      <a href="https://lab.ssafy.com/s03-webmobile1-sub2/s03p12a104">
                        <img
                          class="img img-raised rounded"
                          src="https://cdn.crowdpic.net/list-thumb/thumb_l_A09EC75FC9DCB14CF3A23D68C19927CA.jpg"
                        />
                      </a>
                    </div>
                  </div>
                  <div class="col-md-7">
                    <div class="card-body">
                      <h4 class="card-title">씨 없는 수박</h4>
                      <h6 class="category">요리 블로그 웹 프로젝트</h6>
                      <p class="card-description">
                        SSAFY 3기 2학기 1반 4팀
                        <br />씨 없는 수박입니다
                      </p>
                      <div class="card-footer">
                        <a
                          href="https://lab.ssafy.com/s03-webmobile1-sub2/s03p12a104"
                          class="btn btn-icon btn-neutral btn-github"
                        >
                          <i class="fab fa-github"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </card>
            </div>
            <div class="col-xl-6 col-lg-7 ml-auto mr-auto">
              <card type="profile" plain>
                <div slot="raw-content" class="row">
                  <div class="col-md-5">
                    <div class="card-image">
                      <a href="https://lab.ssafy.com/minkwon4">
                        <img
                          class="img img-raised rounded"
                          src="https://image.shutterstock.com/image-vector/continuous-line-drawing-jesus-simple-260nw-1291866469.jpg"
                        />
                      </a>
                    </div>
                  </div>
                  <div class="col-md-7">
                    <div class="card-body">
                      <h4 class="card-title">권민</h4>
                      <h6 class="category">백엔드 정신적 지주</h6>
                      <p class="card-description">
                        그가 손가락을 휘두르니
                        <br />백엔드에 길이 열리니라
                      </p>
                      <div class="card-footer">
                        <a
                          href="https://lab.ssafy.com/minkwon4"
                          class="btn btn-icon btn-neutral btn-github"
                        >
                          <i class="fab fa-github"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </card>
            </div>
            <div class="col-xl-6 col-lg-7 ml-auto mr-auto">
              <card type="profile" plain>
                <div slot="raw-content" class="row">
                  <div class="col-md-5">
                    <div class="card-image">
                      <a href="https://lab.ssafy.com/sdf7575">
                        <img
                          class="img img-raised rounded"
                          src="https://image.shutterstock.com/image-vector/continuous-line-drawing-man-despair-260nw-1127857904.jpg"
                        />
                      </a>
                    </div>
                  </div>
                  <div class="col-md-7">
                    <div class="card-body">
                      <h4 class="card-title">박태록</h4>
                      <h6 class="category">팀장 프론트엔드</h6>
                      <p class="card-description">
                        중대장은...
                        <br />너희에게 실망했다"
                      </p>
                      <div class="card-footer">
                        <a
                          href="https://lab.ssafy.com/sdf7575"
                          class="btn btn-icon btn-neutral btn-github"
                        >
                          <i class="fab fa-github"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </card>
            </div>
            <div class="col-xl-6 col-lg-7 ml-auto mr-auto">
              <card type="profile" plain>
                <div slot="raw-content" class="row">
                  <div class="col-md-5">
                    <div class="card-image">
                      <a href="https://lab.ssafy.com/lee33843">
                        <img
                          class="img img-raised rounded"
                          src="https://image.shutterstock.com/image-vector/businessman-working-on-laptop-computer-260nw-647903758.jpg"
                        />
                      </a>
                    </div>
                  </div>
                  <div class="col-md-7">
                    <div class="card-body">
                      <h4 class="card-title">이동혁</h4>
                      <h6 class="category">프론트엔드 공장</h6>
                      <p class="card-description">
                        개미는(뚠뚠)오늘도(뚠뚠)
                        <br />열심히 일을 하네(뚠뚠)
                      </p>
                      <div class="card-footer">
                        <a
                          href="https://lab.ssafy.com/lee33843"
                          class="btn btn-icon btn-neutral btn-github"
                        >
                          <i class="fab fa-github"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </card>
            </div>
            <div class="col-xl-6 col-lg-7 ml-auto mr-auto">
              <card type="profile" plain>
                <div slot="raw-content" class="row">
                  <div class="col-md-5">
                    <div class="card-image">
                      <a href="https://lab.ssafy.com/wkddbswjd325">
                        <img
                          class="img img-raised rounded"
                          src="https://ak.picdn.net/shutterstock/videos/1018262020/thumb/7.jpg?ip=x480"
                        />
                      </a>
                    </div>
                  </div>
                  <div class="col-md-7">
                    <div class="card-body">
                      <h4 class="card-title">장윤정</h4>
                      <h6 class="category">백엔드 일꾼</h6>
                      <p class="card-description">
                        신에게는
                        <br />아직 12개의 버그가 남아있사옵니다
                      </p>
                      <div class="card-footer">
                        <a
                          href="https://lab.ssafy.com/wkddbswjd325"
                          class="btn btn-icon btn-neutral btn-github"
                        >
                          <i class="fab fa-github"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </card>
            </div>
            <div class="col-xl-6 col-lg-7 ml-auto mr-auto">
              <card type="profile" plain>
                <div slot="raw-content" class="row">
                  <div class="col-md-5">
                    <div class="card-image">
                      <a href="https://lab.ssafy.com/ryunhoo123">
                        <img
                          class="img img-raised rounded"
                          src="https://images.beano.com/store/e33c42fa25f96017b4e1116701f506459c12116a5693856c6fb70ea26959?auto=compress&w=960&fit=max"
                        />
                      </a>
                    </div>
                  </div>
                  <div class="col-md-7">
                    <div class="card-body">
                      <h4 class="card-title">최원대</h4>
                      <h6 class="category">그루트</h6>
                      <p class="card-description">
                        그루트
                        <br />I'm 그루트
                      </p>
                      <div class="card-footer">
                        <a
                          href="https://lab.ssafy.com/ryunhoo123"
                          class="btn btn-icon btn-neutral btn-github"
                        >
                          <i class="fab fa-github"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </card>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Card, Button, FormGroupInput } from "@/components/global";

export default {
  name: "About",
  data() {
    return {
    };
  },
  components: {
    Card,
    [Button.name]: Button,
    [FormGroupInput.name]: FormGroupInput,
  },
  methods: {
  },
};
</script>
