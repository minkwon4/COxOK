<template>
  <div>
    Hello
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  components: {
    
  }
}
</script>

<style scoped>
</style>
